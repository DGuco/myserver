package stat

// 全局客户登陆数据
var (
	ClientLoginData = NewClientLogin()
	LoginCount      = 0
)

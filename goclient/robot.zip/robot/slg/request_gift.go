package slg

import (
	"github.com/golang/protobuf/proto"
	"time"
	pb "robot/slg/pb"
	"robot/util"
	"robot/stat"
)

//7601:玩家申请礼包信息
func UserRechargeGiftInfoReq(robot *Robot){
	cmd := CMD_USER_GIFT_INFO
	req := &pb.UserRechargeGiftInfoReq{}
	// 序列化协议
	data, err := proto.Marshal(req)
	util.PanicError(err)
	// 发送协议
	robot.Client.sendTime = time.Now()
	robot.Client.Send(cmd, data, func(data []byte) {
		// 回调函数
		res := &pb.UserRechargeGiftInfoRes{}
		err := proto.Unmarshal(data, res)
		util.PanicError(err)

		duration := int64(time.Since(robot.Client.sendTime) / time.Millisecond)
		stat.ClientLoginData.AfterLogin(duration)
		RequstMng.Dispatch(robot, cmd)
	})
}

//7602:玩家申请当前展示的礼包
func UserShowGiftReq(robot *Robot){
	cmd := CMD_GIFT_SHOW
	req := &pb.UserShowGiftReq{}
	// 序列化协议
	data, err := proto.Marshal(req)
	util.PanicError(err)
	// 发送协议
	robot.Client.sendTime = time.Now()
	robot.Client.Send(cmd, data, func(data []byte) {
		// 回调函数
		res := &pb.UserShowGiftRes{}
		err := proto.Unmarshal(data, res)
		util.PanicError(err)

		duration := int64(time.Since(robot.Client.sendTime) / time.Millisecond)
		stat.ClientLoginData.AfterLogin(duration)
		RequstMng.Dispatch(robot, cmd)
	})
}